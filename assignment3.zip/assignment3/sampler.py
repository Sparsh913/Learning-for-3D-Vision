import math
from typing import List

import torch
from ray_utils import RayBundle
from pytorch3d.renderer.cameras import CamerasBase


# Sampler which implements stratified (uniform) point sampling along rays
class StratifiedRaysampler(torch.nn.Module):
    def __init__(
        self,
        cfg
    ):
        super().__init__()

        self.n_pts_per_ray = cfg.n_pts_per_ray
        self.min_depth = cfg.min_depth
        self.max_depth = cfg.max_depth

    def forward(
        self,
        ray_bundle,
    ):
        # TODO (Q1.4): Compute z values for self.n_pts_per_ray points uniformly sampled between [near, far]
        z_vals = None
        z_vals = torch.linspace(self.min_depth, self.max_depth, self.n_pts_per_ray)
        z_vals = z_vals.to(ray_bundle.origins.device)
        print("z_vals", z_vals)

        # TODO (Q1.4): Sample points from z values
        sample_points = None
        print("shape of z_vals", z_vals.shape) # (n_pts_per_ray,)
        print("shape of ray_bundle.directions", ray_bundle.directions.shape) # (N, 3)
        print("shape of ray_bundle.origins", ray_bundle.origins.shape) # (N, 3)
        sample_points = z_vals.unsqueeze(0).unsqueeze(-1).repeat(ray_bundle.origins.shape[0], 1, 1) * ray_bundle.directions.unsqueeze(1).repeat(1, z_vals.shape[0], 1) + ray_bundle.origins.unsqueeze(1).repeat(1, z_vals.shape[0], 1)
        sample_points = sample_points.to(ray_bundle.origins.device)
        print("sample_points", sample_points)
        # sample_lengths=z_vals * torch.ones_like(sample_points[..., :1])
        # print("sample_lengths", sample_lengths)
        # Return
        return ray_bundle._replace(
            sample_points=sample_points,
            sample_lengths=z_vals * torch.ones_like(sample_points[..., :1]),
        )


sampler_dict = {
    'stratified': StratifiedRaysampler
}