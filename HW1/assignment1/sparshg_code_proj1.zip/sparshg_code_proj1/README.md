# Instructions to run my submission for Assignment 1

## Q1.1
Run q1.py
## Q1.2
Run starter > dolly_zoom.py
## Q2
Run q2.py
## Q3
Run q3.py
## Q4
Run starter > camera_transforms.py
## Q5
Run starter > render_generic.py
## Q6
Run q6.py
## Q7
Run q7.py